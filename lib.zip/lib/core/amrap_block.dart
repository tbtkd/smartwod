class AmrapBlock {
  final int workSeconds;
  final int? restSeconds;

  const AmrapBlock({
    required this.workSeconds,
    this.restSeconds,
  });
}
