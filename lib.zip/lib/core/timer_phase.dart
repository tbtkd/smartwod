enum TimerPhase {
  work,
  rest,
  paused,
  finished,
}