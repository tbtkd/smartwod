import 'package:audioplayers/audioplayers.dart';

class FeedbackService {

  static final AudioPlayer _phasePlayer = AudioPlayer()
    ..setPlayerMode(PlayerMode.lowLatency);

  static final AudioPlayer _finishPlayer = AudioPlayer()
    ..setPlayerMode(PlayerMode.lowLatency);

  static final AudioContext _audioContext = AudioContext(
    android: AudioContextAndroid(
      isSpeakerphoneOn: true,
      stayAwake: false,
      contentType: AndroidContentType.sonification,
      usageType: AndroidUsageType.assistanceSonification,
      audioFocus: AndroidAudioFocus.none,
    ),
  );

  static bool _initialized = false;

  static Future<void> _ensureInit() async {
    if (_initialized) return;

    await _phasePlayer.setAudioContext(_audioContext);
    await _finishPlayer.setAudioContext(_audioContext);

    _initialized = true;
  }

  /// 🔥 Inicializa audio context antes de iniciar el entrenamiento
  static Future<void> preload() async {
    await _ensureInit();
  }

  static Future<void> playPhaseChange() async {
    await _ensureInit();
    await _phasePlayer.stop();
    await _phasePlayer.play(
      AssetSource('sounds/phase_change.mp3'),
    );
  }

  static Future<void> playWorkoutFinished() async {
    await _ensureInit();
    await _finishPlayer.stop();
    await _finishPlayer.play(
      AssetSource('sounds/workout_finished.mp3'),
    );
  }
}
