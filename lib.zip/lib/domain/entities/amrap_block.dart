class AmrapBlock {
  final Duration workDuration;
  final Duration? restDuration;

  AmrapBlock({
    required this.workDuration,
    this.restDuration,
  });
}