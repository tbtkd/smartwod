enum WorkoutType {
  amrap,
  emom,
  tabata,
  forTime,
  mix,
}
