abstract class WorkoutAudioService {
  Future<void> playPhaseChange();
  Future<void> playWorkoutFinished();
}
