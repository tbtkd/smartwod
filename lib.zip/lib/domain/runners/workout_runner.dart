abstract class WorkoutRunner {
  void start();
  void togglePause();
  void dispose();
}
