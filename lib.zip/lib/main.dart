import 'package:flutter/material.dart';
import 'app/smartwod_app.dart';

void main() {
  runApp(const SmartWodApp());
}
