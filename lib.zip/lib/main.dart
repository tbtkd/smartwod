import 'package:flutter/material.dart';
import 'app/smartwod_app.dart';

// Punto de entrada de la app
void main() {
  runApp(const SmartWodApp());
}
